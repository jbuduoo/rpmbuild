#!/bin/bash

mkdir -p /opt/ops

tar zxvf ops.tar.gz -C /opt/ops/
mv opsweb /etc/init.d/

tar zxvf libaio.tar.gz -C /

/sbin/chkconfig --add opsweb
chkconfig opsweb on

mv libsigar-amd64-linux.so /lib64
mv libSentinelKeys64.so /lib64

if [[ ! -e /etc/ntp ]]; then
mkdir /etc/ntp
/bin/cp -f keys /etc/ntp/
/bin/cp -f step-tickers /etc/ntp/
/bin/cp -f ntpdate /etc/rc.d/init.d/
/bin/cp -f ntpdateconf /etc/sysconfig/ntpdate
/bin/cp -f ntpdatebin /usr/sbin/ntpdate
fi

if ! id mysql > /dev/null 2>&1; then
groupadd mysql 
useradd -g mysql mysql
fi

/bin/cp -f /opt/ops/db/bin/my_print_defaults /usr/bin/
cp /opt/ops/db/support-files/mysql.server /etc/init.d/opsdb
sed -i 's/^basedir=/basedir=\/opt\/ops\/db/g' /etc/init.d/opsdb
sed -i 's/^datadir=/datadir=\/opt\/ops\/db\/data/g' /etc/init.d/opsdb
/bin/cp -f /opt/ops/db/support-files/my-innodb-heavy-4G.cnf /etc/my.cnf
sed -i 's/log-bin=mysql-bin/#log-bin=mysql-bin/g' /etc/my.cnf
sed -i 's/binlog_format=mixed/#binlog_format=mixed/g' /etc/my.cnf
sed -i 's/max_allowed_packet = 16M/max_allowed_packet = 512M/g' /etc/my.cnf
chown -R root /opt/ops/db 
chown -R mysql /opt/ops/db/data 
chgrp -R mysql /opt/ops/db 
/sbin/chkconfig --add opsdb
chkconfig opsdb on

service opsdb start
service opsweb start

