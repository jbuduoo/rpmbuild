rpmbuild -ba SPECS/ops.spec
